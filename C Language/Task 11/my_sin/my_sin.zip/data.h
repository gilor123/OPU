#define DEVI 0.000001			/*required deviation*/
#define POSITIVE 1
#define NEGATIVE -1
#define RADTODEG 57.2957795128962
#define UNITCERCDEGRS 360		/*Units in the unit circle - i.e. 360 degrees*/
